public class Es10{

      public static boolean scan(String s){
      
         int state = 0, i = 0;
         
         while(state >= 0 && i < s.length())
             {
                 final char ch = s.charAt(i++);
                 char slash = '/';
                 char ast =  '*';
                 char mychar = 'a';
                 switch(state){
                 
                                case 0: //sono in q0 e leggo slash
                                        if(ch == slash)
                                          state = 1;
                                        else if(ch == ast || ch == mychar) state = 0;
                                        else state = -1;
                                        break;
                                        
                                case 1: 
                                        if(ch == ast)
                                           state = 2;
                                        else state = -1;
                                        break;
                                
                                case 2: 
                                        if(ch == ast)
                                           state = 3;
                                        else if(ch == slash)
                                           state = 5;
                                        else state = 2;
                                        break;
                                
                                case 3: 
                                        if(ch == ast)
                                          state = 3;
                                        else if(ch == slash || ch == ast || ch == mychar)
                                          state = 4;
                                        else state = 2;
                                        
                                        break;
                               
                                case 4: 
                                        if(ch == ast || ch == slash || ch != ast || ch != slash)
                                             state = -1;
                                        break;
                                
                                case 5:
                                       if(ch == ast)
                                          state = 3;
                                       else if(ch == slash)
                                          state = 5;
                                       else state = 2;
                                       break;
                                       
                 }
          }
        return state == 4 || state == 0;
      } 
      
      public static void main(String[] args){
      System.out.println(scan(args[0]) ? "DFA RISPONDE : ACCETTATA" : "DFA RISPONDE : NON ACCETTATA");
      
      }


}
