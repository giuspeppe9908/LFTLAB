public class es4{
	public static boolean es1_4(String a){
    int state = 0;
    int i = 0;
    while(state >= 0 && i < a.length())
    {
        
        final char ch = a.charAt(i++);

        switch(state){
                        case 0:
            if((ch >= 48 && ch <= 57) && (ch%2 == 0))
            state = 1;
            else if((ch >= 48 && ch <= 57) && !(ch%2 == 0))
            state = 2;
            else 
            state = -1;
            break;

            case 1:
            if((ch >= 48 && ch <= 57) && (ch%2 == 0))
               state = 1;
            else if((ch >= 48 && ch <= 57) && !(ch%2==0))
	       state = 2;
            else if(ch >= 65 && ch <= 75)
               state = 3;
            else 
               state = -1;
            break;

            case 2:
            if((ch >= 48 && ch <= 57) && (ch%2==0))
	       state = 1;
            else if((ch >= 48 && ch <= 57) && !(ch%2 == 0))
                state = 2;
            else if(ch >= 76 && ch <= 90)
            state = 3;
            else 
            state = -1;
            break;

            /*case 3:
            if(ch >= 65 && ch <= 90)
            state = 3;
            else 
            state = -1;
            break;*/


        }
    }
    return state == 3;
}
	public static void main (String args[]){
	    System.out.println(es1_4(args[0]) ? "ok" : "no");
	}
}
