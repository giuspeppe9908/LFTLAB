class es1{
	public static boolean es1(String a){
	int state = 0;
	int i = 0;
	
	while(state >= 0 && i < a.length()){
		final char ch = a.charAt(i++);  //conta i caratteri di una stringa
		switch (state)  {
			case 0:
			if(ch == 95)			//leggo underscore che corrisponde in tabella ascii a 95 senza apici
			  state = 2;          //e il posto dove va ovvero in q2
			  else if((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122))               //da a piccolo vale 65 e z piccolo vale 90 A grande vale 97 Z grande vale 122
				state = 1;
			  else if (ch >= 48 && ch <= 57) 
				state = -1;
			else state = -1;        // stato pozzo oppure quando viene letto qualsiasi carattere non compreso nell' alfabeto
		    break;
		    
			case 1:
			if((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122))
			state = 1;
			else if ((ch >= 48 && ch <= 57) || (ch == 95))        // in stato q1 ci stanno sia numeri che underscore
			state = 1;
			else state = -1;
	        break;
	        
	        case 2:
	        if(ch == 95)
	        state = 2;
	        else if((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122)) 
	        state = 1;
			  else if (ch >= 48 && ch <= 57) 
			   state = -1;
	        else state = -1;
	        break;
		}
	}
	return state == 1;
			
	}
	public static void main (String args[]){
		System.out.println(es1(args[0]) ? "true" : "false");  //?=if, :=else args[0] perchè l'indice 0 corrisponde al primo carattere della stringa
	}
	
}
