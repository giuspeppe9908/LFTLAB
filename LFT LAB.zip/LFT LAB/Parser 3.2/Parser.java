import java.io.*;
public class Parser {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;
    public Parser(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() {
        look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) {
	throw new Error("near line " + lex.line + " : " + s);
    }

    void match(int t) {
	if (look.tag == t) {
	    if (look.tag != Tag.EOF) move();
	} else error("syntax error");
    }

    //metodo public prog
    public void prog(){
       statlist();
       match(Tag.EOF);
    }
    
    private void statlist(){
       /*statlist -> stat, statlistp*/
       stat();
       statlistp();
    }
    
    private void statlistp(){
            if(look.tag == ';'){
            match(';');
            stat();
            statlistp();
            }
    }
    
    private void stat(){
      switch(look.tag){
         case '=':
                   match('=');
                   if(look.tag == Tag.ID)
                     match(Tag.ID);
                     expr();
                   break;
                       
         case Tag.PRINT: /* print( <exprlist> ) */
                       match(Tag.PRINT);
                       match(Token.lpt.tag);
                       exprlist();
                       match(Token.rpt.tag);
                       break;
         
         case Tag.READ:
                       match(Tag.READ);
                       match(Token.lpt.tag);
                       match(Tag.ID);
                       match(Token.rpt.tag);
                       break;
         
         
         case Tag.COND:
                        match(Tag.COND);/*matcho parola chiave cond*/
                        whenlist();
                        match(Tag.ELSE);
                        stat();
                        break;
      
         case Tag.WHILE:
                          match(Tag.WHILE);
                          match(Token.lpt.tag);
                          bexpr();
                          match(Token.rpt.tag);
                          stat();
                          break;
         
         case '{':
                            match('{');
                            statlist();
                            match('}');
                            break;   

        }  
      }
      
      private void bexpr() {
        match(Tag.RELOP);
        expr();
        expr();

     }

    private void expr() {
        switch(look.tag){
        
             case '+':
                       match('+');
                       exprlist();
                       break;
             
             case '-':
                       match('-');
                       expr();
                       expr();
                       break;
             
             case '*':
                       match('*');
                       exprlist();
                       break;       
            
             case '/':
                       match('/');
                       expr();
                       expr();
                       break;
             
             case Tag.NUM:
                          match(Tag.NUM);
                          break;
             
             case Tag.ID:
                         match(Tag.ID);
                         break;
        }
    }
    
    private void exprlist(){
           expr();
           exprlistp();
    }
    
    private void exprlistp(){
          if(look.tag == '+' || look.tag == '-' || look.tag == '*' || look.tag == '/' || look.tag == Tag.NUM || look.tag == Tag.ID){
          expr();
          exprlistp();
          }
          //epsilon ??
    }
    
    private void whenlist(){
         whenitem();
         whenlistp();
    }
    
    private void whenlistp(){
         if(look.tag == Tag.WHEN){
           whenitem();
           whenlistp();
         }
    }
    
    private void whenitem(){
        match(Tag.WHEN);
        match('(');
        bexpr();
        match(')');
        match(Tag.DO);
        stat();
    }

    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = "/home/giuseppe/Desktop/UNITO/2° ANNO/lft2020/LAB/Parser 3.2/test.txt"; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Parser parser = new Parser(lex, br);
            parser.prog();
            System.out.println("Input OK");
            br.close();
        } catch (IOException e) {e.printStackTrace();}
    }
}
