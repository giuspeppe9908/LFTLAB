import java.io.*;

public class Translator {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;
    
    SymbolTable st = new SymbolTable();
    CodeGenerator code = new CodeGenerator();
    int count=0;

    public Translator(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() { 
	// come in Esercizio 3.1
	look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) { 
	// come in Esercizio 3.1
	throw new Error("near line " + lex.line + " : " + s);
    }

    void match(int t) {
	// come in Esercizio 3.1
	if (look.tag == t) {
	    if (look.tag != Tag.EOF) move();
	} else error("syntax error");
    }

    public void prog() {        
	// ... completare ...
	if(look.tag == '=' || look.tag == Tag.READ){
        int lnext_prog = code.newLabel();
        statlist(lnext_prog);
        code.emitLabel(lnext_prog);
        match(Tag.EOF);
        try {
        	code.toJasmin();
        }
        catch(java.io.IOException e) {
        	System.out.println("IO error\n");
        };
       }
       else error("Error! You have to declare your variables!\n");
	// ... completare ...
    }

    public void stat(int lnext_prog) {
        switch(look.tag) {
	    //... completare ...
            case Tag.READ:
                match(Tag.READ);
                match('(');
                if (look.tag==Tag.ID){
                    int id_addr = st.lookupAddress(((Word)look).lexeme);
                    if (id_addr==-1) {
                        id_addr = count;
                        st.insert(((Word)look).lexeme,count++);
                    }                    
                    match(Tag.ID);
                    match(')');
                    code.emit(OpCode.invokestatic,0);
                    code.emit(OpCode.istore,id_addr);
		    // ... completare ...  
                }
                else
                    error("Error in grammar (stat) after read( with " + look);
                break;
            /*case PRINT*/
            
            case Tag.PRINT:
                match(Tag.PRINT);
                match('(');
                exprlist();
                match(')');
                code.emit(OpCode.invokestatic,1);
                break;
                
            case '=': /* = nome_var costante*/
                     match('=');
                     if(look.tag==Tag.ID){
                      	int id_addr = st.lookupAddress(((Word)look).lexeme);
                      	if (id_addr==-1){
                        	id_addr = count;
                        	st.insert(((Word)look).lexeme,count++);
                      	}        
                      	match(Tag.ID);  
                      	expr();          
                      	code.emit(OpCode.istore,id_addr);
                      }
                     else
                          error("Error in grammar (stat) after read( with " + look);
                break;
             
             case Tag.COND:
                             match(Tag.COND);/*matcho parola chiave cond*/
                             /*sono in cond creo 2 label e le chiamo t ed f*/
                             int t = code.newLabel();
                             int f = code.newLabel();
                             //code.emitLabel(t);
                             whenlist(t, f);
                             /*effettuo controllo con un if per capire se il tag successivo è ELSE e quindi*/
                             if(look.tag == Tag.ELSE){
                              match(Tag.ELSE);//matcho il tag il che mi fa capire che sono nella seconda parte della produzione
                              code.emit(OpCode.GOto, lnext_prog);//con il goto mi porto alla label next
                              code.emitLabel(f);//MA inserisco quella falsa nel codice.
                             }
                             stat(lnext_prog);/*Sia che eseguo un if (B) S1 oppure if(B) S1 ELSE S2 
                                              concludo con il richiamo della funzione stat.
                                              Uso sempre le parentesi { } sia dopo il DO che nell'else anche se ho
                                              una sola operazione.*/
                             break;
             	
             case Tag.WHILE:
			    match(Tag.WHILE);
			    match('(');
                             int ltrue = code.newLabel();//label condizione true
                             int lnext = code.newLabel();//label condizione false
			    int cond_end = code.newLabel();//label condizione di FINE WHILE
			    if(ltrue != 0) /*confronto se il VALORE di l_true != 0 ( in quanto ovviamente sono una label
			                     successiva a quella di ritorno (L0)*/	
			    code.emit(OpCode.GOto, ltrue);//se questo controllo va a buon fine vado alla label successiva ( true )
                	    code.emitLabel(ltrue);//la inserisco nel codice di Output.j
                	    bexpr(lnext, cond_end);/*in bexpr utilizzo lnext (ovvero label falsa e cond_end) mi servono per 
                	                             far si che lnext risulti come parametro true, mentre cond_end come label false*/
                             match(')');
                             code.emitLabel(lnext);/*inserisco nel file Output.j la label false*/
                             stat(ltrue);/*mentre in stat passo come parametro la label vera*/
			    code.emit(OpCode.GOto, ltrue);//salto condizionato alla label vera
			    code.emitLabel(cond_end);//emetto label cond. uscita.
			    break;
             case '{':
                            match('{');
                            statlist(lnext_prog);
                            match('}');
                            break;
	// ... completare ...
        }
     }
    /*funzione bexpr(t,f)*/
    private void bexpr(int ltrue, int lfalse) {
		if(look == Word.gt) { /* > */
			match(Tag.RELOP);
			expr();
			expr();
			code.emit(OpCode.if_icmpgt,ltrue);
			code.emit(OpCode.GOto,lfalse);
		}
		if(look == Word.lt) { /* < */
			match(Tag.RELOP);
			expr();
			expr();
			code.emit(OpCode.if_icmplt,ltrue);
			code.emit(OpCode.GOto,lfalse);
		}
		if (look == Word.eq) { /* == */
			match(Tag.RELOP);
			expr();
			expr();
			code.emit(OpCode.if_icmpeq,ltrue);
			code.emit(OpCode.GOto,lfalse);
		}
		if(look == Word.ne) { /* <> */
			match(Tag.RELOP);
			expr();
			expr();
			code.emit(OpCode.if_icmpne,ltrue);
			code.emit(OpCode.GOto,lfalse);
		}
		if(look == Word.le) { /*<=*/
			match(Tag.RELOP);
			expr();
			expr();
			code.emit(OpCode.if_icmple,ltrue);
			code.emit(OpCode.GOto,lfalse);
		}
		if(look == Word.ge) { /* >= */
			match(Tag.RELOP);
			expr();
			expr();
			code.emit(OpCode.if_icmpge,ltrue);
			code.emit(OpCode.GOto,lfalse);
		}
		
		
	}

    
    private void statlist(int new_lab){
       stat(new_lab);
       statlistp();
    }
    
    private void statlistp(){
            if(look.tag == ';'){
            match(';');
            int lab = code.newLabel();
            stat(lab);
            code.emitLabel(lab);
            statlistp();
            }
    }
    
    private void expr(){
        int id_addr;
        switch(look.tag){
	// ... completare ...
            case '-':
                match('-');
                expr();
                expr();
                code.emit(OpCode.isub);
                break;
            
             case '+':
                match('+');
                match('(');
                exprlist();
                match(')');
                code.emit(OpCode.iadd);
                break;
             
              case '*':
                match('*');
                match('(');
                exprlist();
                match(')');
                code.emit(OpCode.imul);
                break;
                
              case '/':
                match('/');
                expr();
                expr();
                code.emit(OpCode.idiv);
                break;
              
              case Tag.NUM:
                          int nmb = 0;
                      	 nmb = ((NumberTok)look).n;
                      	 match(Tag.NUM);
                      	 code.emit(OpCode.ldc, nmb);
                          break;
          
             case Tag.ID:
                         id_addr = st.lookupAddress(((Word)look).lexeme);
                         if(id_addr == -1)
                         error("You have to inizialize the variable : "+look);
                         else{
                          match(Tag.ID);
                          code.emit(OpCode.iload, id_addr);
                         }
                         break;
	// ... completare ...
        }
    }
    
    private void exprlist(){
              expr();
              exprlistp();
    }
    
    private void exprlistp(){
          if(look.tag == '+' || look.tag == '-' || look.tag == '*' || look.tag == '/' || look.tag == Tag.NUM || look.tag == Tag.ID){
          expr();
          exprlistp();
          }
          //epsilon ??
    }
    
    private void whenlist(int t, int lbl){
         whenitem(t,lbl);
         whenlistp(t,lbl);
    }
    
    private void whenlistp(int t,int lbl){
         if(look.tag == Tag.WHEN){
           whenitem(t,lbl);
           whenlistp(t,lbl);
         }
    }
    
    private void whenitem(int t, int f){
        match(Tag.WHEN);
        int l_F = code.newLabel(); // when falso
        match('(');
        bexpr(t, f);
        match(')');
        code.emitLabel(t);
        match(Tag.DO);
        //code.emit(OpCode.GOto, t);
        stat(f);
        code.emitLabel(f);
    }
    // ... completare ...
    public static void main(String[] args){
           Lexer lex = new Lexer();
           String path = "A.lft"; // il percorso del file da tradurre
           try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Translator translator = new Translator(lex, br);
            translator.prog();
            System.out.println("File Tradotto Correttamente.");
            br.close();
           } catch (IOException e) {e.printStackTrace();}
    }
}
