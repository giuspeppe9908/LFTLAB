public class NumberTok extends Token {
	// ... completare ...
	public static int n;
    	public NumberTok(int s) { super(Tag.NUM); n = s; }
    	public String toString() { return "<" + Tag.NUM + ", " + n + ">"; }
}

