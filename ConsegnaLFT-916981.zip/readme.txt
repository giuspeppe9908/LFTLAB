**** Studenti che hanno aderito al progetto ****
Lobascio Giuseppe Pio | Mat: 916981 | Turno LAB: T3
Fouah Manal           |Mat: 931322  | Turno LAB : T2
Erraihani Abir        | Mat: 921220 | Turlo LAB : T2 
************************************************
