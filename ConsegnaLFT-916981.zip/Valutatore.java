import java.io.*;
public class Valutatore {
private Lexer lex;
private BufferedReader pbr;
private Token look;
 public Valutatore(Lexer l, BufferedReader br) {
	lex = l;
	pbr = br;
	move();
 }
 void move() {
  // come in Esercizio 3.1
  look = lex.lexical_scan(pbr);
  System.out.println("token = " + look);
 }
 void error(String s) {
 // come in Esercizio 3.1
 throw new Error("near line " + lex.line + " : " + s);
 }
 void match(int t) {
  // come in Esercizio 3.1
  if (look.tag == t) {
	    if (look.tag != Tag.EOF) move();
  } else error("syntax error");
 }
 public void start() {
  int expr_val;
  // ... completare ...
  expr_val = expr();
  match(Tag.EOF);
  System.out.print("Valutatore ha calcolato l'espressione, restituisce >> ");
  System.out.println(expr_val);
  // ... completare ...
 }
 private int expr() {
  int term_val, exprp_val;
  // ... completare ...
  term_val = term();
  exprp_val = exprp(term_val);
  // ... completare ...
  return exprp_val;
 }
 
 private int exprp(int exprp_i) {
  int term_val, exprp_val;
  switch (look.tag) {
  case '+':
    match('+');
    term_val = term();
    exprp_val = exprp(exprp_i + term_val);
  break;
  case '-':
    match('-');
    term_val = term();
    exprp_val = exprp(exprp_i - term_val);
  break;
  
  default: exprp_val = exprp_i; 
  }
  return exprp_val;
}
 private int term() {
  // ... completare ...
  int termp_i, term_val;
  termp_i = fact();
  term_val = termp(termp_i);
  return term_val;
 }
 private int termp(int termp_i) {
  // ... completare ...
  int fact_val, termp_val, termp1_i;
        switch (look.tag) {
	case '*':
                match('*');
                fact_val = fact();
                termp_val = termp(termp_i * fact_val);
                break;
        case '/':
                match('/');
                fact_val = fact();
                termp_val = termp(termp_i / fact_val);
                break;
                
        default: termp_val = termp_i;
        }
        return termp_val;
 }
 
 private int fact() {
  // ... completare ...
  int fact_val = 0, expr_val;
  switch(look.tag){
     case '(':
               match('(');
               fact_val = expr();
               match(')');
               break;
               
     case Tag.NUM:
                fact_val = ((NumberTok)look).n;/*upcast di look con richiamo all'attributo 
                                               n ovvero intero, che mi permette di inserire 
                                               NUM.value richiesto */
                match(Tag.NUM);
                break;
     
     default: fact_val = 0;
              error("Syntax error");
              break;
  }
  return fact_val;
 }
  public static void main(String[] args) {
    Lexer lex = new Lexer();
    String path = "test.txt"; // il percorso del file da leggere / file da leggere
    try {
          BufferedReader br = new BufferedReader(new FileReader(path));
          Valutatore valutatore = new Valutatore(lex, br);
          valutatore.start();
          /*N.B. : Dopo i token, c'é presenza di un numero che equivale al risultato dell'espressione presente in test.txt*/
          br.close();
    }
    catch(IOException e){ e.printStackTrace(); }
  }
}
