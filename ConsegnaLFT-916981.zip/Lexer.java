import java.io.*; 
import java.util.*;

public class Lexer {

    public static int line = 1;
    private char peek = ' ';
    String identificatore = "";
    String Numero = "";
    
    private void readch(BufferedReader br) {
        try {
            peek = (char) br.read();
        } catch (IOException exc) {
            peek = (char) -1; // ERROR
        }
    }
    
    public Token lexical_scan(BufferedReader br) {
        while (peek == ' ' || peek == '\t' || peek == '\n'  || peek == '\r') {
            if (peek == '\n') line++;
            readch(br);
        }
        
        switch (peek) {
            case '!':
                peek = ' ';
                return Token.not;

	// ... gestire i casi SINGOLI di (, ), {, }, +, -, *, /, ; ... //
            case '(':
                  peek = ' ';
                  return Token.lpt;
            
            case ')':
                  peek = ' ';
                  return Token.rpt;
            
            case '{':
                  peek = ' ';
                  return Token.lpg;
            
            case '}':
                  peek = ' ';
                  return Token.rpg;           
         
            
            case '+':
                  peek = ' ';
                  return Token.plus;
            
            case '-':
                  peek = ' ';
                  return Token.minus;
            
            case '*':
                  peek = ' ';
                  return Token.mult;
                  
            case '/':
                  readch(br);
                  if(peek == '/') return lexical_scan(br);/* leggo // e ritorno il lexical_scan(br);*/
                  else if(Character.isLetter(peek) || Character.isDigit(peek)) return Token.div;
                  else if(peek == '*'){ /*leggo asterisco inizio commento*/
                     readch(br);
                     boolean flag = false;//per capire quando finisce il commento /**/.
                     while(peek != '\n' || !flag){
                        if(peek == (char) -1) break;
                        readch(br);
                          if(peek == '*'){
                            readch(br);
                            if(peek == '/')
                              flag = true;
                          }
                     }
                    
                  if (!flag) {
                        System.out.println("Errore causato dalla sezione commenti.");
                        return new Token(Tag.EOF);
                    } else {
                        readch(br);
                        return lexical_scan(br);
                    }
                 }
                 else if (peek != '/') {
                    readch(br);
                    while (peek != '\n') readch(br);
                    readch(br);
                    return lexical_scan(br);
                }
                  
            case ';':
                  peek = ' ';
                  return Token.semicolon;
                  
            // ... gestire i casi di ||, <, >, <=, >=, ==, <>, = ... //
            case '&':
                readch(br);
                if (peek == '&') {
                    peek = ' ';
                    return Word.and;
                } else {
                    System.err.println("Erroneous character"
                            + " after & : "  + peek );
                    return null;
                }
            
            case '|':
                readch(br);
                if (peek == '|') {
                    peek = ' ';
                    return Word.or;
                } else {
                    System.err.println("Erroneous character"
                            + " after | : "  + peek );
                    return null;
                }
             
             case '<':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.le;
                } else if(peek == '>'){
                         peek = ' ';
                         return Word.ne;
                  }
                  else
                        return Word.lt;
            
            case '>':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.ge;
                } else {
                         return Word.gt;
                }
                
             case '=':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.eq;
                } else {
                          return Token.assign;
                }
                
	    case '_':
	         /*ABBIAMO LETTO GIA' _ */
	         /* dobbiamo leggere altri caratteri.*/
	         /* readch(br)*/
	         identificatore += peek;
	         readch(br);
	         while(Character.isDigit(peek) || Character.isLetter(peek) || peek == '_'){
                            identificatore = identificatore + peek;
                            readch(br);/*leggo altro carattere*/
                 }
	         String f  = identificatore;
	         identificatore = ""; 
	         return new Word(Tag.ID, f);
	         
   
            case (char)-1:
                return new Token(Tag.EOF);

            default:
                if (Character.isLetter(peek)){
	           // ... gestire il caso degli identificatori e delle parole chiave //
	              
	              while(Character.isLetter(peek)){
	                identificatore += peek;/*associa ogni volta un carattere nuovo a identificatore tramite variabile char peek.*/
                        readch(br);/*leggo il carattere da br...*/
                      }
                      /*parole chiave*/
                      switch(identificatore){
                            case "cond": 
                                           identificatore = "";
                                           return Word.cond;
                                           
                            case "then": 
                                           identificatore = "";
                                           return Word.then;
                            
                            case "when": 
                                           identificatore = "";
                                           return Word.when;
                            
                            case "else": 
                                           identificatore = "";
                                           return Word.elsetok;
                            
                            case "while": 
                                           identificatore = "";
                                           return Word.whiletok;
                            
                            case "do": 
                                           identificatore = "";
                                           return Word.dotok;
                            
                            case "seq": 
                                           identificatore = "";
                                           return Word.seq;
                            
                            case "print": 
                                           identificatore = "";
                                           return Word.print;
                                           
                            case "read": 
                                           identificatore = "";
                                           return Word.read;
                           
                      }
                    /*identificatore con numero e underscore*/
                    if((Character.isDigit(peek) && identificatore != "") || peek == '_'){
                        identificatore = identificatore + peek;
                        readch(br);/*leggo un altro carattere*/
                        while(Character.isDigit(peek) || Character.isLetter(peek) || peek == '_'){
                            identificatore = identificatore + peek;
                            readch(br);/*leggo altro carattere*/
                        }
                    }
                    //identificatore = "";
                    String x = identificatore;
                    identificatore = "";
                    return new Word(Tag.ID,x);

                } else if (Character.isDigit(peek)) {

	          // ... gestire il caso dei numeri ... //
	          while(Character.isDigit(peek)){
                        Numero = Numero + peek;
                        readch(br);
                    }
                    String x = Numero;
                    Numero = "";
                    return new NumberTok(Integer.parseInt(x));


                } else {
                        System.err.println("Erroneous character: " 
                                + peek );
                        return null;
                }
         }
       
    }
		
    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = "file.txt"; //Il percorso del file da leggere//
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Token tok;
            do {
                tok = lex.lexical_scan(br);
                System.out.println("Scan: " + tok);
            } while (tok.tag != Tag.EOF);
            br.close();
        } catch (IOException e) {e.printStackTrace();}    
    }

}

