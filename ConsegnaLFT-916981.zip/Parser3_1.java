import java.io.*;
public class Parser3_1{
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;
    public Parser3_1(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() {
        look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) {
	throw new Error("near line " + lex.line + " : " + s);
    }

    void match(int t) {
	if (look.tag == t) {
	    if (look.tag != Tag.EOF) move();
	} else error("syntax error");
    }

    public void start() {  
	while(look.tag != Tag.EOF){
	   expr();
	}
	match(Tag.EOF);
	return;
    }

    private void expr() { 
		if(look.tag == '(' || look.tag == Tag.NUM){	/*insieme guida*/
			term();
			exprp(); 
		}else error("syntax error found in expr().\n");
    }
    private void exprp() { 
			switch (look.tag) { 
		
			case '+':
				match('+'); 
				term(); 
				exprp(); 
				break;
		
			case '-':
				match('-'); 
				term(); 
				exprp(); 
				break;
		        
		        case '(':
				  break;
			
			case Tag.EOF:
				  break;
		
			case ')':
				  break;
		        default : 
		                 error("syntax error found in exprp().\n");
			}
	}
	
	private void term() {
		if(look.tag == '(' || look.tag == Tag.NUM){
			fact();
			termp();
		}
		else error("syntax error found in term().\n");
	}
	
	private void termp() { 
			switch (look.tag) { 
			
			case '*':
				match('*');
				fact();
				termp(); 
				break;
			
			case '/':
				match('/');
				fact();
				termp(); 
				break;
		
			case '(':
                               break;

                        case '+': 
                               break;
        
                        case '-': 
                               break;
                        
                        case ')':
                               break;
                        
                        case Tag.EOF:
                               break;
                               
		        default : error("syntax error termp");
		}
	}	
	
	private void fact() { 
		if(look.tag == Tag.NUM || look.tag == '(') {
			switch (look.tag) {
				case '(': 
					match('(');
					expr();
					match(')');
					break;
			
				case Tag.NUM:		
					match(look.tag);	
					break;
			}
		}
		else error("syntax error found in fact().\n");
	
	}

    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = "test.txt"; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Parser3_1 parser = new Parser3_1(lex, br);
            parser.start();
            System.out.println("Input OK");
            br.close();
        } catch (IOException e) {e.printStackTrace();}
    }
}
