public class NumberTok extends Token {
	// ... completare ...
	int n = 0;
    	public NumberTok(int s) { super(Tag.NUM); n = s; }
    	public String toString() { return "<" + Tag.NUM + ", " + n + ">"; }
}

