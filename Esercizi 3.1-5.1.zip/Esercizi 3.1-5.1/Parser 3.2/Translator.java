import java.io.*;

public class Translator {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;
    
    SymbolTable st = new SymbolTable();
    CodeGenerator code = new CodeGenerator();
    int count=0;

    public Translator(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() { 
	// come in Esercizio 3.1
	look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) { 
	// come in Esercizio 3.1
	throw new Error("near line " + lex.line + " : " + s);
    }

    void match(int t) {
	// come in Esercizio 3.1
	if (look.tag == t) {
	    if (look.tag != Tag.EOF) move();
	} else error("syntax error");
    }

    public void prog() {        
	// ... completare ...
        int lnext_prog = code.newLabel();
        statlist(lnext_prog);
        code.emitLabel(lnext_prog);
        match(Tag.EOF);
        try {
        	code.toJasmin();
        }
        catch(java.io.IOException e) {
        	System.out.println("IO error\n");
        };
	// ... completare ...
    }

    public void stat() {
        int lnext_prog = code.newLabel();
        switch(look.tag) {
	    //... completare ...
            case Tag.READ:
                match(Tag.READ);
                match('(');
                if (look.tag==Tag.ID) {
                    int id_addr = st.lookupAddress(((Word)look).lexeme);
                    if (id_addr==-1) {
                        id_addr = count;
                        st.insert(((Word)look).lexeme,count++);
                    }                    
                    match(Tag.ID);
                    match(')');
                    code.emit(OpCode.invokestatic,0);
                    code.emit(OpCode.istore,id_addr);
                    code.emitLabel(lnext_prog);//creo label successiva.
		    // ... completare ...  
                }
                else
                    error("Error in grammar (stat) after read( with " + look);
                break;
            /*case PRINT*/
            
            case Tag.PRINT:
                match(Tag.PRINT);
                match('(');
                exprlist();
                match(')');
                code.emit(OpCode.invokestatic,1);//per la print mettere 1 <-- argomento della print.
                code.emitLabel(lnext_prog);//creo label successiva.
                break;
                
            case '=': /* = nome_var costante*/
                     match('=');
                     if(look.tag==Tag.ID){
                      	int id_addr = st.lookupAddress(((Word)look).lexeme);
                      	if (id_addr==-1) {
                        	id_addr = count;
                        	st.insert(((Word)look).lexeme,count++);
                      	}        
                      	match(Tag.ID);            
                      	int nmb = 0;
                      	nmb = ((NumberTok)look).n;
                      	match(Tag.NUM);
                      	code.emit(OpCode.ldc, nmb);
                      	code.emit(OpCode.istore,id_addr);
                      	code.emitLabel(lnext_prog);//creo label successiva
                     }
                     else
                          error("Error in grammar (stat) after read( with " + look);
                break;
             
             case Tag.COND:
                        match(Tag.COND);/*matcho parola chiave cond*/
                        whenlist();
                        match(Tag.ELSE);
                        code.emit(OpCode.GOto, lnext_prog);
                        stat();
                        break;
             
             case Tag.WHILE:
                          match(Tag.WHILE);
                          match('(');
                          bexpr();
                          match(')');
                          stat();
                          break;
             case '{':
                            match('{');
                            statlist(lnext_prog);
                            match('}');
                            break;
	// ... completare ...
        }
     }
    /*bexpr()*/
    private void bexpr(){
        int lbl = code.newLabel();
        if(look == Word.gt){  
          match(Tag.RELOP);
          expr();
          expr();
          code.emit(OpCode.if_icmpgt, lbl);
        }
        if(look == Word.lt){
         match(Tag.RELOP);
         expr();
         expr();
         code.emit(OpCode.if_icmplt, lbl);
        }
        if(look == Word.le){  
          match(Tag.RELOP);
          expr();
          expr();
          code.emit(OpCode.if_icmple, lbl);
        }
        if(look == Word.ne){
          match(Tag.RELOP);
          expr();
          expr();
          code.emit(OpCode.ifne, lbl);
        }
        if(look == Word.ge){  
          match(Tag.RELOP);
          expr();
          expr();
          code.emit(OpCode.if_icmpge, lbl);
        }
        if(look == Word.eq){
         match(Tag.RELOP);
         expr();
         expr();
         code.emit(OpCode.if_icmpeq, lbl);
        }
        if(look == Word.ne){
          match(Tag.RELOP);
          expr();
          expr();
          code.emit(OpCode.if_icmpne, lbl);
        }
     }
    
    private void statlist(int lnext){
       /*statlist -> stat, statlistp*/
       stat();
       statlistp(lnext);
    }
    
    private void statlistp(int label_next){
            if(look.tag == ';'){
            match(';');
            label_next = label_next+1;
            stat();
            statlistp(label_next);
            }
    }
    
    private void expr(){
        int id_addr;
        switch(look.tag){
	// ... completare ...
            case '-':
                match('-');
                expr();
                expr();
                code.emit(OpCode.isub);
                break;
            
             case '+':
                match('+');
                match('(');
                exprlist();
                match(')');
                code.emit(OpCode.iadd);
                break;
             
              case '*':
                match('*');
                match('(');
                exprlist();
                match(')');
                code.emit(OpCode.imul);
                break;
                
              case '/':
                match('/');
                expr();
                expr();
                code.emit(OpCode.idiv);
                break;
              
              case Tag.NUM:
                          int nmb = 0;
                      	 nmb = ((NumberTok)look).n;
                      	 match(Tag.NUM);
                      	 code.emit(OpCode.ldc, nmb);
                          break;
          
             case Tag.ID:
                         id_addr = st.lookupAddress(((Word)look).lexeme);
                         match(Tag.ID);
                         code.emit(OpCode.iload, id_addr);
                         break;
	// ... completare ...
        }
    }
    
    private void exprlist(){
              expr();
              exprlistp();
    }
    
    private void exprlistp(){
          if(look.tag == '+' || look.tag == '-' || look.tag == '*' || look.tag == '/' || look.tag == Tag.NUM || look.tag == Tag.ID){
          expr();
          exprlistp();
          }
          //epsilon ??
    }
    
    private void whenlist(){
         whenitem();
         whenlistp();
    }
    
    private void whenlistp(){
         if(look.tag == Tag.WHEN){
           whenitem();
           whenlistp();
         }
    }
    
    private void whenitem(){
        match(Tag.WHEN);
        match('(');
        bexpr();
        match(')');
        match(Tag.DO);
        stat();
    }
    // ... completare ...
    public static void main(String[] args){
           Lexer lex = new Lexer();
           String path = "A.lft"; // il percorso del file da tradurre
           try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Translator translator = new Translator(lex, br);
            translator.prog();
            System.out.println("File Tradotto Correttamente.");
            br.close();
           } catch (IOException e) {e.printStackTrace();}
    }
}

