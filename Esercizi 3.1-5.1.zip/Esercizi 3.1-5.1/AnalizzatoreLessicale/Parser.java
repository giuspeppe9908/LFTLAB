import java.io.*;
public class Parser {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;
    public Parser(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() {
        look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) {
	throw new Error("near line " + lex.line + " : " + s);
    }

    void match(int t) {
	if (look.tag == t) {
	    if (look.tag != Tag.EOF) move();
	} else error("syntax error");
    }

    public void start() {  
	expr();
	match(Tag.EOF);
	if(look.tag == ')')
	   error("Error in start() method.\n");
    }

    private void expr() { 
		if(look.tag == '(' || look.tag == Tag.NUM){	/*insieme guida*/
			term();
			exprp(); 
		}else error("syntax error found in expr().\n");
    }
    private void exprp() { 
		if(look.tag == '+' || look.tag == '-' || look.tag == Tag.EOF || look.tag == ')') {
			switch (look.tag) { 
		
			case '+':
				match('+'); 
				term(); 
				exprp(); 
				break;
		
			case '-':
				match('-'); 
				term(); 
				exprp(); 
				break;
		
			case Tag.EOF:
				break;
		
			case ')':
				break;
			}
		}
		else error("syntax error found in exprp().\n");
	
	}
	
	private void term() {
		if(look.tag == '(' || look.tag == Tag.NUM){
			fact();
			termp();
		}
		else error("syntax error found in term().\n");

	}
	
	private void termp() { 
		if(look.tag == '+' || look.tag == '-' || look.tag == Tag.EOF || look.tag == ')' || look.tag == '*' || look.tag == '/') {
			switch (look.tag) { 
			
			case '*':
				match('*');
				fact();
				termp(); 
				break;
			
			case '/':
				match('/');
				fact();
				termp(); 
				break;
		
			case '+': 
				break;//epsilon
		
			case '-': 
				break;//epsilon
		
			case ')':
				break;//epsilon
			
			case Tag.EOF:
				break;//epsilon
		
			}
		}
		else error("syntax error termp");
	
	}	
	
	private void fact() { 
		if(look.tag == Tag.NUM || look.tag == '(') {
			switch (look.tag) {
				case '(': 
					match('(');
					expr();
					match(')');
					break;
			
				case Tag.NUM:		
					match(look.tag);	
					break;
			}
		}
		else error("syntax error found in fact().\n");
	
	}

    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = "test.txt"; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Parser parser = new Parser(lex, br);
            parser.start();
            System.out.println("Input OK");
            br.close();
        } catch (IOException e) {e.printStackTrace();}
    }
}
