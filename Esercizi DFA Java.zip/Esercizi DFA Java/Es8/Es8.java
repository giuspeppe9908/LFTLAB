public class Es8{

    public static boolean scan(String s){
          int state = 0, i=0;
             while(state >= 0 && i < s.length())
             {
                 final char ch = s.charAt(i++);

                 switch(state){
                               
                              //caso 0 --> leggo P oppure  p
                              case 0: 
                                       if(ch == 'p' || ch == 'P')
                                            state = 1;//leggo P e vado in stato 1.
                                       else if(Character.isLetter(ch)) state = 4;
                                       else state = -1;
                                       break;
                              
                              case 1: 
                                       if(ch == 'i' || ch == 'I')
                                         state = 2;//leggo I o i e vado in 2
                                       else if(Character.isLetter(ch)) state = 5;
                                       else state = -1;
                                       break;
                              
                              case 2: 
                                      if(Character.isLetter(ch)) state = 3; //sono alla o
                                      else  state = -1;
                                      break;
                              
                              case 3: 
                                      state = -1;
                                      break;
                              case 4: 
                                      if(ch == 'i' || ch == 'I') state = 5;
                                      else state = -1;
                                      break;
                              
                              case 5: 
                                     if(ch == 'o' || ch == 'O') state = 3;
                                     else state = -1;
                                     break;
                                     
                              default: state = -1;
                                       break;
                             
                 }
             }
            return state == 3;
    }
    
    public static void main(String[] args){
      System.out.println(scan(args[0]) ? "ACCETTATA" : "NON ACCETTATA");
    }

}
