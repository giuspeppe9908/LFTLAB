public class es4{
public static boolean scan(String a){
    int state = 0, i=0;
             while(state >= 0 && i < s.length())
             {
                 final char ch = s.charAt(i++);

                 switch(state){
                	case 0:
				    if((ch >= 48 && ch <= 57) && (ch%2==0))
				        state = 1;
				    else if((ch >= 48 && ch <= 57) && !(ch%2==0))
				        state = 2;
				    else 
				        state = -1;
				    break;

                        case 1:
				    if((ch >= 48 && ch <= 57) && (ch%2==0))
				        state = 1;
				    else if((ch >= 48 && ch <= 57) && !(ch%2==0))
				        state = 2;
				    else if((ch >= 65 && ch <= 75))
				        state = 3;
				    else if((ch >= 76 && ch <= 90))
				        state = -1;
				    break;

                       case 2:
				    if((ch >= 48 && ch <= 57) && (ch%2==0))
				        state = 1;
				     else if((ch >= 48 && ch <= 57) && !(ch%2==0))
				        state = 2;
				    else if((ch >= 65 && ch <= 75))
				         state = -1;
				    else if((ch >= 76 && ch <= 90))
				        state = 3;
				    break;
               }
           }
           
           return state == 3;
}
public static void main (String args[]){
    System.out.println(scan(args[0]) ? "ok" : "no");
}
}
